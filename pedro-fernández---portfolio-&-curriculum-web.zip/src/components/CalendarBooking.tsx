import React, { useState } from 'react';
import { motion } from 'motion/react';
import { PROFILE_DATA } from '../data/profileData';
import { 
  Calendar as CalendarIcon, 
  Clock, 
  User, 
  Mail, 
  FileText, 
  CheckCircle2, 
  ExternalLink, 
  Sparkles, 
  Copy, 
  Check,
  Video,
  AlertCircle
} from 'lucide-react';

interface CalendarBookingProps {
  preselectedService?: string;
}

export const CalendarBooking: React.FC<CalendarBookingProps> = ({ preselectedService }) => {
  const [selectedMeetingId, setSelectedMeetingId] = useState<string>('tech_consultation');
  const [selectedDate, setSelectedDate] = useState<string>(() => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  });
  const [selectedTime, setSelectedTime] = useState<string>('10:00');
  const [clientName, setClientName] = useState<string>('');
  const [clientEmail, setClientEmail] = useState<string>('');
  const [projectTopic, setProjectTopic] = useState<string>(preselectedService || 'Consultoría de Desarrollo Fullstack');
  const [copiedLink, setCopiedLink] = useState(false);
  const [bookingSuccess, setBookingSuccess] = useState(false);

  const availableTimeSlots = [
    '09:00', '10:00', '11:00', '14:00', '15:30', '17:00'
  ];

  const selectedMeeting = PROFILE_DATA.googleCalendar.meetingOptions.find(m => m.id === selectedMeetingId) || PROFILE_DATA.googleCalendar.meetingOptions[0];

  // Helper to generate Google Calendar Event URL
  const buildGoogleCalendarUrl = () => {
    const title = encodeURIComponent(`Reunión: ${selectedMeeting.title} - ${clientName || 'Cliente'}`);
    
    // Construct Start and End ISO Dates
    const startDateTime = new Date(`${selectedDate}T${selectedTime}:00`);
    const endDateTime = new Date(startDateTime.getTime() + selectedMeeting.durationMinutes * 60 * 1000);

    const formatGoogleDate = (d: Date) => {
      return d.toISOString().replace(/-|:|\.\d\d\d/g, '');
    };

    const datesParam = `${formatGoogleDate(startDateTime)}/${formatGoogleDate(endDateTime)}`;
    
    const details = encodeURIComponent(
      `Reunión agendada desde el portafolio web de Pedro Fernández.\n\n` +
      `👤 Cliente: ${clientName || 'No especificado'}\n` +
      `✉️ Email: ${clientEmail || 'No especificado'}\n` +
      `📌 Tema / Servicio: ${projectTopic}\n` +
      `⏱️ Duración: ${selectedMeeting.duration}\n\n` +
      `Contacto directo: pedropaff7@gmail.com | +58 414-2792806`
    );

    const addEmail = encodeURIComponent(PROFILE_DATA.googleCalendar.calendarEmail);

    return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${title}&dates=${datesParam}&details=${details}&add=${addEmail}`;
  };

  const handleOpenGoogleCalendar = (e: React.FormEvent) => {
    e.preventDefault();
    const url = buildGoogleCalendarUrl();
    window.open(url, '_blank', 'noopener,noreferrer');
    setBookingSuccess(true);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(buildGoogleCalendarUrl());
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  return (
    <section id="agendar" className="py-20 relative z-10 bg-slate-950/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="flex items-center justify-center space-x-3 mb-3">
            <div className="w-8 h-[1px] bg-[#d4af37]" />
            <p className="text-xs uppercase tracking-[0.4em] text-[#d4af37] font-sans font-medium">
              Google Calendar Sync
            </p>
            <div className="w-8 h-[1px] bg-[#d4af37]" />
          </div>
          <h2 className="text-3xl sm:text-5xl font-serif font-light text-white leading-tight">
            Reserva una Cita Virtual
          </h2>
          <p className="mt-3 text-white/60 text-sm font-sans font-light">
            Selecciona el tipo de consultoría, elige la fecha y horario que mejor se adapte a tu agenda e intégralo a tu Google Calendar con 1-click.
          </p>
        </div>

        {/* Main Scheduler Interface */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Meeting Options Selection */}
          <div className="lg:col-span-5 space-y-4">
            <h3 className="text-[10px] uppercase tracking-[0.25em] font-medium text-[#d4af37] mb-2 font-sans">
              1. Selecciona el Tipo de Cita
            </h3>

            {PROFILE_DATA.googleCalendar.meetingOptions.map((option) => {
              const isSelected = option.id === selectedMeetingId;
              return (
                <div
                  key={option.id}
                  onClick={() => setSelectedMeetingId(option.id)}
                  className={`p-5 border cursor-pointer transition-all duration-200 ${
                    isSelected
                      ? 'bg-[#111111] border-[#d4af37]'
                      : 'bg-[#0a0a0a] hover:bg-[#141414] border-white/10'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3 mb-2 font-sans">
                    <h4 className={`text-base font-serif ${isSelected ? 'text-[#d4af37]' : 'text-white'}`}>
                      {option.title}
                    </h4>
                    <span className="text-[10px] font-sans uppercase tracking-widest px-2.5 py-1 bg-[#d4af37]/10 text-[#d4af37] border border-[#d4af37]/40 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {option.duration}
                    </span>
                  </div>

                  <p className="text-xs text-white/60 font-sans font-light leading-relaxed mb-3">
                    {option.description}
                  </p>

                  <div className="flex items-center justify-between text-[10px] uppercase tracking-widest pt-3 border-t border-white/10 font-sans">
                    <span className="text-[#d4af37] font-medium">{option.type}</span>
                    <span className={`text-[10px] ${isSelected ? 'text-[#d4af37] font-bold' : 'text-white/40'}`}>
                      {isSelected ? '✓ Seleccionado' : 'Hacer clic para seleccionar'}
                    </span>
                  </div>
                </div>
              );
            })}

            {/* Direct Google Calendar Link Box */}
            <div className="p-5 bg-[#111111] border border-white/10 flex flex-col gap-3 font-sans">
              <div className="flex items-center gap-2 text-xs uppercase tracking-wider font-medium text-[#d4af37]">
                <Video className="w-4 h-4 text-[#d4af37]" />
                <span>Modalidad: Google Meet</span>
              </div>
              <p className="text-xs text-white/60 font-light">
                Al confirmar la cita, recibirás automáticamente la invitación en tu Google Calendar con el enlace de videollamada incluido.
              </p>
            </div>
          </div>

          {/* Right Column: Date, Time & Info Form */}
          <div className="lg:col-span-7 bg-[#111111] p-6 sm:p-8 border border-white/10 font-sans">
            <h3 className="text-[10px] uppercase tracking-[0.25em] font-medium text-[#d4af37] mb-6">
              2. Configura los Detalles e Integra con tu Calendar
            </h3>

            <form onSubmit={handleOpenGoogleCalendar} className="space-y-6">
              
              {/* Date & Time Picker */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs uppercase tracking-wider text-white/80 mb-2">
                    Fecha Preferida
                  </label>
                  <div className="relative">
                    <input
                      type="date"
                      value={selectedDate}
                      onChange={(e) => setSelectedDate(e.target.value)}
                      min={new Date().toISOString().split('T')[0]}
                      required
                      className="w-full px-4 py-3 bg-[#0a0a0a] border border-white/10 text-white text-xs focus:outline-none focus:border-[#d4af37]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs uppercase tracking-wider text-white/80 mb-2">
                    Horario Disponible (Hora VE / Remoto)
                  </label>
                  <select
                    value={selectedTime}
                    onChange={(e) => setSelectedTime(e.target.value)}
                    className="w-full px-4 py-3 bg-[#0a0a0a] border border-white/10 text-white text-xs focus:outline-none focus:border-[#d4af37]"
                  >
                    {availableTimeSlots.map((slot) => (
                      <option key={slot} value={slot}>
                        {slot} hs (Turno {parseInt(slot) < 12 ? 'Mañana' : 'Tarde'})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Client Name & Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs uppercase tracking-wider text-white/80 mb-2">
                    Tu Nombre Completo
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-white/40 absolute left-3.5 top-3.5" />
                    <input
                      type="text"
                      value={clientName}
                      onChange={(e) => setClientName(e.target.value)}
                      placeholder="Ej. Carlos Mendoza"
                      required
                      className="w-full pl-10 pr-4 py-3 bg-[#0a0a0a] border border-white/10 text-white text-xs focus:outline-none focus:border-[#d4af37]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs uppercase tracking-wider text-white/80 mb-2">
                    Tu Correo Electrónico
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-white/40 absolute left-3.5 top-3.5" />
                    <input
                      type="email"
                      value={clientEmail}
                      onChange={(e) => setClientEmail(e.target.value)}
                      placeholder="ejemplo@empresa.com"
                      required
                      className="w-full pl-10 pr-4 py-3 bg-[#0a0a0a] border border-white/10 text-white text-xs focus:outline-none focus:border-[#d4af37]"
                    />
                  </div>
                </div>
              </div>

              {/* Topic / Project Notes */}
              <div>
                <label className="block text-xs uppercase tracking-wider text-white/80 mb-2">
                  Tema o Proyecto a Tratar
                </label>
                <div className="relative">
                  <FileText className="w-4 h-4 text-white/40 absolute left-3.5 top-3.5" />
                  <input
                    type="text"
                    value={projectTopic}
                    onChange={(e) => setProjectTopic(e.target.value)}
                    placeholder="Ej. Integración de Pasarela de Pago PayPal / Desarrollo API"
                    required
                    className="w-full pl-10 pr-4 py-3 bg-[#0a0a0a] border border-white/10 text-white text-xs focus:outline-none focus:border-[#d4af37]"
                  />
                </div>
              </div>

              {/* Summary Box */}
              <div className="p-4 bg-[#0a0a0a] border border-white/10 text-xs space-y-2">
                <div className="flex justify-between uppercase tracking-wider text-white/80">
                  <span>Resumen:</span>
                  <span className="text-[#d4af37] font-serif">{selectedMeeting.title} ({selectedMeeting.duration})</span>
                </div>
                <div className="flex justify-between text-white/50">
                  <span>Fecha y Hora:</span>
                  <span className="text-white/80">{selectedDate} a las {selectedTime} hs</span>
                </div>
                <div className="flex justify-between text-white/50">
                  <span>Invitado Principal:</span>
                  <span className="text-white/80">{PROFILE_DATA.googleCalendar.calendarEmail}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-3 pt-2">
                <button
                  type="submit"
                  className="w-full py-4 px-6 text-xs uppercase font-bold tracking-[0.2em] text-black bg-[#d4af37] hover:bg-[#c39f2f] transition-all flex items-center justify-center gap-3"
                >
                  <CalendarIcon className="w-4 h-4" />
                  <span>Agendar en Google Calendar</span>
                  <ExternalLink className="w-4 h-4" />
                </button>

                <div className="flex items-center justify-between text-xs text-white/50">
                  <button
                    type="button"
                    onClick={handleCopyLink}
                    className="flex items-center gap-1.5 hover:text-[#d4af37] transition-colors"
                  >
                    {copiedLink ? <Check className="w-3.5 h-3.5 text-[#d4af37]" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedLink ? '¡Enlace copiado!' : 'Copiar enlace al evento'}</span>
                  </button>

                  <a
                    href={PROFILE_DATA.contact.whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#d4af37] hover:underline"
                  >
                    ¿Coordinar por WhatsApp?
                  </a>
                </div>
              </div>

              {/* Success Banner Notice */}
              {bookingSuccess && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-4 bg-[#0a0a0a] border border-[#d4af37] text-[#d4af37] text-xs flex items-center gap-3"
                >
                  <CheckCircle2 className="w-5 h-5 text-[#d4af37] flex-shrink-0" />
                  <div>
                    <p className="font-bold uppercase tracking-wider">¡Ventana de Google Calendar Abierta!</p>
                    <p className="text-[11px] text-white/70 mt-0.5">
                      Guarda el evento en tu Google Calendar para confirmar. Pedro recibirá la notificación de inmediato.
                    </p>
                  </div>
                </motion.div>
              )}

            </form>
          </div>

        </div>

      </div>
    </section>
  );
};
